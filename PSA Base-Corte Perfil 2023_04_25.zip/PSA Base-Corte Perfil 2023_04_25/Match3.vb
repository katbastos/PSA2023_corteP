﻿Module Match3
    ' Rotinas de Acesso ao Módulo Match3
    Class LeituraPosicao
        Public PosEixoX As Double

    End Class
    Sub Main()
        'Public PosX As LeituraPosicao = New LeituraPosicao

        'PosX.PosEixoX = 5.5

    End Sub


    Public Sub PosEixoXTeste()
        'MainForm.txt_ManPosX.Text = "5.5"

    End Sub
End Module
