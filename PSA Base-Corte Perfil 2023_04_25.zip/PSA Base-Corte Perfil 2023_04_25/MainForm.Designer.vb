﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.TabCtrl_Option = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.pic_gifMan = New System.Windows.Forms.PictureBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btn_ManMovToPos = New System.Windows.Forms.Button()
        Me.btn_ManSet = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_PosManEixoX = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txt_ManFeedRate = New System.Windows.Forms.TextBox()
        Me.btn_ManZMenos = New System.Windows.Forms.Button()
        Me.trackBar_ManFeed = New System.Windows.Forms.TrackBar()
        Me.btn_ManZMais = New System.Windows.Forms.Button()
        Me.label127 = New System.Windows.Forms.Label()
        Me.btn_ManYmenos = New System.Windows.Forms.Button()
        Me.btn_ManXmenos = New System.Windows.Forms.Button()
        Me.btn_ManYMais = New System.Windows.Forms.Button()
        Me.btn_ManXmais = New System.Windows.Forms.Button()
        Me.Panel_PosActual_Man = New System.Windows.Forms.Panel()
        Me.label122 = New System.Windows.Forms.Label()
        Me.txt_ManPosX = New System.Windows.Forms.TextBox()
        Me.label131 = New System.Windows.Forms.Label()
        Me.label125 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.pic_gifAut = New System.Windows.Forms.PictureBox()
        Me.label11 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_VelX_3 = New System.Windows.Forms.TextBox()
        Me.txt_VelX_2 = New System.Windows.Forms.TextBox()
        Me.txt_ManCodG = New System.Windows.Forms.TextBox()
        Me.label22 = New System.Windows.Forms.Label()
        Me.btn_ManRun = New System.Windows.Forms.Button()
        Me.btn_ManValidCodeG = New System.Windows.Forms.Button()
        Me.label20 = New System.Windows.Forms.Label()
        Me.label18 = New System.Windows.Forms.Label()
        Me.txt_VelX_1 = New System.Windows.Forms.TextBox()
        Me.txt_PosX_3 = New System.Windows.Forms.TextBox()
        Me.txt_PosX_2 = New System.Windows.Forms.TextBox()
        Me.txt_PosX_1 = New System.Windows.Forms.TextBox()
        Me.label16 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_PosAutEixoX = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Button_close = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.StatusStripLbl_Modo = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SairToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManualToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AutomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProgramasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabelasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ParâmetrosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AvisosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tmr_match3 = New System.Windows.Forms.Timer(Me.components)
        Me.TabCtrl_Option.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.pic_gifMan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.trackBar_ManFeed, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_PosActual_Man.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.pic_gifAut, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabCtrl_Option
        '
        Me.TabCtrl_Option.Controls.Add(Me.TabPage1)
        Me.TabCtrl_Option.Controls.Add(Me.TabPage2)
        Me.TabCtrl_Option.Controls.Add(Me.TabPage3)
        Me.TabCtrl_Option.Controls.Add(Me.TabPage4)
        Me.TabCtrl_Option.Controls.Add(Me.TabPage5)
        Me.TabCtrl_Option.Controls.Add(Me.TabPage6)
        Me.TabCtrl_Option.Controls.Add(Me.TabPage7)
        Me.TabCtrl_Option.ImageList = Me.ImageList1
        resources.ApplyResources(Me.TabCtrl_Option, "TabCtrl_Option")
        Me.TabCtrl_Option.Multiline = True
        Me.TabCtrl_Option.Name = "TabCtrl_Option"
        Me.TabCtrl_Option.SelectedIndex = 0
        Me.TabCtrl_Option.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.LightGray
        Me.TabPage1.Controls.Add(Me.pic_gifMan)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Panel2)
        Me.TabPage1.Controls.Add(Me.Panel_PosActual_Man)
        Me.TabPage1.Controls.Add(Me.label125)
        resources.ApplyResources(Me.TabPage1, "TabPage1")
        Me.TabPage1.Name = "TabPage1"
        '
        'pic_gifMan
        '
        Me.pic_gifMan.Image = Global.CmdNum.My.Resources.Resources.ezgif_com_video_to_gif
        resources.ApplyResources(Me.pic_gifMan, "pic_gifMan")
        Me.pic_gifMan.Name = "pic_gifMan"
        Me.pic_gifMan.TabStop = False
        '
        'Label12
        '
        Me.Label12.AllowDrop = True
        Me.Label12.BackColor = System.Drawing.Color.DarkGray
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label10)
        Me.Panel3.Controls.Add(Me.btn_ManMovToPos)
        Me.Panel3.Controls.Add(Me.btn_ManSet)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.txt_PosManEixoX)
        resources.ApplyResources(Me.Panel3, "Panel3")
        Me.Panel3.Name = "Panel3"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'btn_ManMovToPos
        '
        resources.ApplyResources(Me.btn_ManMovToPos, "btn_ManMovToPos")
        Me.btn_ManMovToPos.Name = "btn_ManMovToPos"
        Me.btn_ManMovToPos.UseVisualStyleBackColor = True
        '
        'btn_ManSet
        '
        resources.ApplyResources(Me.btn_ManSet, "btn_ManSet")
        Me.btn_ManSet.Name = "btn_ManSet"
        Me.btn_ManSet.UseVisualStyleBackColor = True
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'txt_PosManEixoX
        '
        Me.txt_PosManEixoX.BackColor = System.Drawing.SystemColors.Info
        Me.txt_PosManEixoX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_PosManEixoX, "txt_PosManEixoX")
        Me.txt_PosManEixoX.Name = "txt_PosManEixoX"
        '
        'Label8
        '
        Me.Label8.AllowDrop = True
        Me.Label8.BackColor = System.Drawing.Color.DarkGray
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.txt_ManFeedRate)
        Me.Panel2.Controls.Add(Me.btn_ManZMenos)
        Me.Panel2.Controls.Add(Me.trackBar_ManFeed)
        Me.Panel2.Controls.Add(Me.btn_ManZMais)
        Me.Panel2.Controls.Add(Me.label127)
        Me.Panel2.Controls.Add(Me.btn_ManYmenos)
        Me.Panel2.Controls.Add(Me.btn_ManXmenos)
        Me.Panel2.Controls.Add(Me.btn_ManYMais)
        Me.Panel2.Controls.Add(Me.btn_ManXmais)
        resources.ApplyResources(Me.Panel2, "Panel2")
        Me.Panel2.Name = "Panel2"
        '
        'txt_ManFeedRate
        '
        Me.txt_ManFeedRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_ManFeedRate, "txt_ManFeedRate")
        Me.txt_ManFeedRate.Name = "txt_ManFeedRate"
        '
        'btn_ManZMenos
        '
        resources.ApplyResources(Me.btn_ManZMenos, "btn_ManZMenos")
        Me.btn_ManZMenos.Name = "btn_ManZMenos"
        Me.btn_ManZMenos.UseVisualStyleBackColor = True
        '
        'trackBar_ManFeed
        '
        resources.ApplyResources(Me.trackBar_ManFeed, "trackBar_ManFeed")
        Me.trackBar_ManFeed.Maximum = 100
        Me.trackBar_ManFeed.Name = "trackBar_ManFeed"
        '
        'btn_ManZMais
        '
        resources.ApplyResources(Me.btn_ManZMais, "btn_ManZMais")
        Me.btn_ManZMais.Name = "btn_ManZMais"
        Me.btn_ManZMais.UseVisualStyleBackColor = True
        '
        'label127
        '
        resources.ApplyResources(Me.label127, "label127")
        Me.label127.Name = "label127"
        '
        'btn_ManYmenos
        '
        resources.ApplyResources(Me.btn_ManYmenos, "btn_ManYmenos")
        Me.btn_ManYmenos.Name = "btn_ManYmenos"
        '
        'btn_ManXmenos
        '
        resources.ApplyResources(Me.btn_ManXmenos, "btn_ManXmenos")
        Me.btn_ManXmenos.Name = "btn_ManXmenos"
        Me.btn_ManXmenos.UseVisualStyleBackColor = True
        '
        'btn_ManYMais
        '
        resources.ApplyResources(Me.btn_ManYMais, "btn_ManYMais")
        Me.btn_ManYMais.Name = "btn_ManYMais"
        Me.btn_ManYMais.UseVisualStyleBackColor = True
        '
        'btn_ManXmais
        '
        resources.ApplyResources(Me.btn_ManXmais, "btn_ManXmais")
        Me.btn_ManXmais.Name = "btn_ManXmais"
        Me.btn_ManXmais.UseVisualStyleBackColor = True
        '
        'Panel_PosActual_Man
        '
        Me.Panel_PosActual_Man.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel_PosActual_Man.Controls.Add(Me.label122)
        Me.Panel_PosActual_Man.Controls.Add(Me.txt_ManPosX)
        Me.Panel_PosActual_Man.Controls.Add(Me.label131)
        resources.ApplyResources(Me.Panel_PosActual_Man, "Panel_PosActual_Man")
        Me.Panel_PosActual_Man.Name = "Panel_PosActual_Man"
        '
        'label122
        '
        resources.ApplyResources(Me.label122, "label122")
        Me.label122.Name = "label122"
        '
        'txt_ManPosX
        '
        Me.txt_ManPosX.BackColor = System.Drawing.SystemColors.Info
        Me.txt_ManPosX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_ManPosX, "txt_ManPosX")
        Me.txt_ManPosX.Name = "txt_ManPosX"
        '
        'label131
        '
        resources.ApplyResources(Me.label131, "label131")
        Me.label131.Name = "label131"
        '
        'label125
        '
        Me.label125.AllowDrop = True
        Me.label125.BackColor = System.Drawing.Color.DarkGray
        Me.label125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.label125, "label125")
        Me.label125.Name = "label125"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.LightGray
        resources.ApplyResources(Me.TabPage2, "TabPage2")
        Me.TabPage2.Controls.Add(Me.pic_gifAut)
        Me.TabPage2.Controls.Add(Me.label11)
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Controls.Add(Me.Panel1)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Name = "TabPage2"
        '
        'pic_gifAut
        '
        Me.pic_gifAut.Image = Global.CmdNum.My.Resources.Resources.ezgif_com_video_to_gif
        resources.ApplyResources(Me.pic_gifAut, "pic_gifAut")
        Me.pic_gifAut.Name = "pic_gifAut"
        Me.pic_gifAut.TabStop = False
        '
        'label11
        '
        Me.label11.AllowDrop = True
        Me.label11.BackColor = System.Drawing.Color.DarkGray
        Me.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.label11, "label11")
        Me.label11.Name = "label11"
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Controls.Add(Me.txt_VelX_3)
        Me.Panel4.Controls.Add(Me.txt_VelX_2)
        Me.Panel4.Controls.Add(Me.txt_ManCodG)
        Me.Panel4.Controls.Add(Me.label22)
        Me.Panel4.Controls.Add(Me.btn_ManRun)
        Me.Panel4.Controls.Add(Me.btn_ManValidCodeG)
        Me.Panel4.Controls.Add(Me.label20)
        Me.Panel4.Controls.Add(Me.label18)
        Me.Panel4.Controls.Add(Me.txt_VelX_1)
        Me.Panel4.Controls.Add(Me.txt_PosX_3)
        Me.Panel4.Controls.Add(Me.txt_PosX_2)
        Me.Panel4.Controls.Add(Me.txt_PosX_1)
        Me.Panel4.Controls.Add(Me.label16)
        resources.ApplyResources(Me.Panel4, "Panel4")
        Me.Panel4.Name = "Panel4"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'txt_VelX_3
        '
        Me.txt_VelX_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_VelX_3, "txt_VelX_3")
        Me.txt_VelX_3.Name = "txt_VelX_3"
        '
        'txt_VelX_2
        '
        Me.txt_VelX_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_VelX_2, "txt_VelX_2")
        Me.txt_VelX_2.Name = "txt_VelX_2"
        '
        'txt_ManCodG
        '
        Me.txt_ManCodG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_ManCodG, "txt_ManCodG")
        Me.txt_ManCodG.Name = "txt_ManCodG"
        '
        'label22
        '
        resources.ApplyResources(Me.label22, "label22")
        Me.label22.Name = "label22"
        '
        'btn_ManRun
        '
        resources.ApplyResources(Me.btn_ManRun, "btn_ManRun")
        Me.btn_ManRun.Name = "btn_ManRun"
        Me.btn_ManRun.UseVisualStyleBackColor = True
        '
        'btn_ManValidCodeG
        '
        resources.ApplyResources(Me.btn_ManValidCodeG, "btn_ManValidCodeG")
        Me.btn_ManValidCodeG.Name = "btn_ManValidCodeG"
        Me.btn_ManValidCodeG.UseVisualStyleBackColor = True
        '
        'label20
        '
        resources.ApplyResources(Me.label20, "label20")
        Me.label20.Name = "label20"
        '
        'label18
        '
        resources.ApplyResources(Me.label18, "label18")
        Me.label18.Name = "label18"
        '
        'txt_VelX_1
        '
        Me.txt_VelX_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_VelX_1, "txt_VelX_1")
        Me.txt_VelX_1.Name = "txt_VelX_1"
        '
        'txt_PosX_3
        '
        Me.txt_PosX_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_PosX_3, "txt_PosX_3")
        Me.txt_PosX_3.Name = "txt_PosX_3"
        '
        'txt_PosX_2
        '
        Me.txt_PosX_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_PosX_2, "txt_PosX_2")
        Me.txt_PosX_2.Name = "txt_PosX_2"
        '
        'txt_PosX_1
        '
        Me.txt_PosX_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_PosX_1, "txt_PosX_1")
        Me.txt_PosX_1.Name = "txt_PosX_1"
        '
        'label16
        '
        resources.ApplyResources(Me.label16, "label16")
        Me.label16.Name = "label16"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.txt_PosAutEixoX)
        Me.Panel1.Controls.Add(Me.Label6)
        resources.ApplyResources(Me.Panel1, "Panel1")
        Me.Panel1.Name = "Panel1"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'txt_PosAutEixoX
        '
        Me.txt_PosAutEixoX.BackColor = System.Drawing.SystemColors.Info
        Me.txt_PosAutEixoX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.txt_PosAutEixoX, "txt_PosAutEixoX")
        Me.txt_PosAutEixoX.Name = "txt_PosAutEixoX"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'Label7
        '
        Me.Label7.AllowDrop = True
        Me.Label7.BackColor = System.Drawing.Color.DarkGray
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.LightGray
        resources.ApplyResources(Me.TabPage3, "TabPage3")
        Me.TabPage3.Name = "TabPage3"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.LightGray
        resources.ApplyResources(Me.TabPage4, "TabPage4")
        Me.TabPage4.Name = "TabPage4"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.LightGray
        resources.ApplyResources(Me.TabPage5, "TabPage5")
        Me.TabPage5.Name = "TabPage5"
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.LightGray
        resources.ApplyResources(Me.TabPage6, "TabPage6")
        Me.TabPage6.Name = "TabPage6"
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.LightGray
        Me.TabPage7.Controls.Add(Me.Button_close)
        resources.ApplyResources(Me.TabPage7, "TabPage7")
        Me.TabPage7.Name = "TabPage7"
        '
        'Button_close
        '
        resources.ApplyResources(Me.Button_close, "Button_close")
        Me.Button_close.Name = "Button_close"
        Me.Button_close.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "Avisos2.png")
        Me.ImageList1.Images.SetKeyName(1, "man1.png")
        Me.ImageList1.Images.SetKeyName(2, "Programas.png")
        Me.ImageList1.Images.SetKeyName(3, "Opções.png")
        Me.ImageList1.Images.SetKeyName(4, "Aut.png")
        Me.ImageList1.Images.SetKeyName(5, "apresentacao.PNG")
        Me.ImageList1.Images.SetKeyName(6, "Parametros.png")
        Me.ImageList1.Images.SetKeyName(7, "Tabelas.png")
        '
        'StatusStrip
        '
        Me.StatusStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusStripLbl_Modo})
        resources.ApplyResources(Me.StatusStrip, "StatusStrip")
        Me.StatusStrip.Name = "StatusStrip"
        '
        'StatusStripLbl_Modo
        '
        Me.StatusStripLbl_Modo.Name = "StatusStripLbl_Modo"
        resources.ApplyResources(Me.StatusStripLbl_Modo, "StatusStripLbl_Modo")
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ManualToolStripMenuItem, Me.AutomToolStripMenuItem, Me.ProgramasToolStripMenuItem, Me.TabelasToolStripMenuItem, Me.ParâmetrosToolStripMenuItem, Me.AvisosToolStripMenuItem})
        resources.ApplyResources(Me.MenuStrip1, "MenuStrip1")
        Me.MenuStrip1.Name = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SairToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        resources.ApplyResources(Me.FileToolStripMenuItem, "FileToolStripMenuItem")
        '
        'SairToolStripMenuItem
        '
        Me.SairToolStripMenuItem.Name = "SairToolStripMenuItem"
        resources.ApplyResources(Me.SairToolStripMenuItem, "SairToolStripMenuItem")
        '
        'ManualToolStripMenuItem
        '
        Me.ManualToolStripMenuItem.Name = "ManualToolStripMenuItem"
        resources.ApplyResources(Me.ManualToolStripMenuItem, "ManualToolStripMenuItem")
        '
        'AutomToolStripMenuItem
        '
        Me.AutomToolStripMenuItem.Name = "AutomToolStripMenuItem"
        resources.ApplyResources(Me.AutomToolStripMenuItem, "AutomToolStripMenuItem")
        '
        'ProgramasToolStripMenuItem
        '
        Me.ProgramasToolStripMenuItem.Name = "ProgramasToolStripMenuItem"
        resources.ApplyResources(Me.ProgramasToolStripMenuItem, "ProgramasToolStripMenuItem")
        '
        'TabelasToolStripMenuItem
        '
        Me.TabelasToolStripMenuItem.Name = "TabelasToolStripMenuItem"
        resources.ApplyResources(Me.TabelasToolStripMenuItem, "TabelasToolStripMenuItem")
        '
        'ParâmetrosToolStripMenuItem
        '
        Me.ParâmetrosToolStripMenuItem.Name = "ParâmetrosToolStripMenuItem"
        resources.ApplyResources(Me.ParâmetrosToolStripMenuItem, "ParâmetrosToolStripMenuItem")
        '
        'AvisosToolStripMenuItem
        '
        Me.AvisosToolStripMenuItem.Name = "AvisosToolStripMenuItem"
        resources.ApplyResources(Me.AvisosToolStripMenuItem, "AvisosToolStripMenuItem")
        '
        'tmr_match3
        '
        '
        'MainForm
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.TabCtrl_Option)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MainForm"
        Me.TabCtrl_Option.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.pic_gifMan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.trackBar_ManFeed, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_PosActual_Man.ResumeLayout(False)
        Me.Panel_PosActual_Man.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.pic_gifAut, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents ImageList1 As ImageList
    Private WithEvents TabCtrl_Option As TabControl
    Private WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents label125 As Label
    Friend WithEvents Panel_PosActual_Man As Panel
    Private WithEvents label122 As Label
    Private WithEvents label131 As Label
    Private WithEvents label127 As Label
    Private WithEvents trackBar_ManFeed As TrackBar
    Friend WithEvents Panel1 As Panel
    Private WithEvents Label5 As Label
    Private WithEvents txt_PosAutEixoX As TextBox
    Private WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel2 As Panel
    Private WithEvents btn_ManZMenos As Button
    Private WithEvents btn_ManZMais As Button
    Private WithEvents btn_ManYmenos As Button
    Private WithEvents btn_ManXmenos As Button
    Private WithEvents btn_ManYMais As Button
    Private WithEvents btn_ManXmais As Button
    Friend WithEvents StatusStrip As StatusStrip
    Friend WithEvents StatusStripLbl_Modo As ToolStripStatusLabel
    Private WithEvents btn_ManSet As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SairToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManualToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AutomToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProgramasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabelasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ParâmetrosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AvisosToolStripMenuItem As ToolStripMenuItem
    Public WithEvents txt_ManPosX As TextBox
    Friend WithEvents tmr_match3 As Timer
    Private WithEvents Label10 As Label
    Private WithEvents Label9 As Label
    Private WithEvents txt_PosManEixoX As TextBox
    Private WithEvents btn_ManMovToPos As Button
    Friend WithEvents Label12 As Label
    Friend WithEvents Panel3 As Panel
    Public WithEvents txt_ManFeedRate As TextBox
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents Button_close As Button
    Friend WithEvents label11 As Label
    Private WithEvents Panel4 As Panel
    Private WithEvents txt_ManCodG As TextBox
    Private WithEvents label22 As Label
    Private WithEvents btn_ManRun As Button
    Private WithEvents btn_ManValidCodeG As Button
    Private WithEvents label20 As Label
    Private WithEvents label18 As Label
    Public WithEvents txt_VelX_1 As TextBox
    Public WithEvents txt_PosX_3 As TextBox
    Public WithEvents txt_PosX_2 As TextBox
    Public WithEvents txt_PosX_1 As TextBox
    Private WithEvents label16 As Label
    Public WithEvents txt_VelX_3 As TextBox
    Public WithEvents txt_VelX_2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents pic_gifMan As PictureBox
    Friend WithEvents pic_gifAut As PictureBox
End Class
