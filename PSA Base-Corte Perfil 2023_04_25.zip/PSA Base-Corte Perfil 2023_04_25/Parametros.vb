﻿Module Parametros

End Module
