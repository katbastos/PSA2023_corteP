﻿Module Automatico
    ' Rotinas Modo Automático

End Module
